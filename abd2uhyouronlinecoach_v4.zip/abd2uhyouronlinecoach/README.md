# abd2uhyouronlinecoach (v2)

A static website for online gym coaching that:

- asks for **age / height / weight / gender / goal**
- generates:
  - **gym split (3–6 days/week)**
  - **nutrition targets (calories + macros)**
  - **7-day weekly meal plan** with **exact portions** (eggs, bread, chicken, etc.)
- includes a **calorie tracker** with a daily food log saved in the browser (localStorage)
- includes **pricing offers** + **contact** section + share link buttons

## Run locally
Open `index.html` in your browser.

If you prefer a local server:

```bash
cd abd2uhyouronlinecoach
python -m http.server 8080
```

Then open: http://localhost:8080

## Customize coach contact + payments
Edit `script.js`:

- `COACH.email`
- `COACH.instagramHandle`
- `COACH.whatsappUrl`
- Optional: add Stripe/PayPal checkout URLs in `COACH.checkout`

## Photo credits (Unsplash)
- Male hero: Luke Witter (k47w6BeapCs)
- Female hero: Sven Mieke (jO6vBWX9h9Y)
- Dumbbells: Samuel Girven (VJ2s0c20qCo)
- Food: Brooke Lark (HlNcigvUi4Q)

(See footer for credits. Unsplash license applies.)


## Default coach contact (already set)
- Email: abd2uhyouronlinecoach@gmail.com
- Instagram: @abd2uhyouronlinecoach
- WhatsApp: +358408145114


## Payments
To connect real payments, add your checkout URL in `script.js` → `COACH.checkout.personal`.
