/* abd2uhyouronlinecoach — generator + weekly meal plan + calorie tracker + pricing/contact helpers
   Runs fully in the browser (static site, no backend).
*/
const $ = (sel) => document.querySelector(sel);

// ------------------------------
// COACH SETTINGS (edit these)
// ------------------------------
const COACH = {
  email: "abd2uhyouronlinecoach@gmail.com",
  instagramHandle: "abd2uhyouronlinecoach",
  whatsappUrl: "https://wa.me/358408145114?text=Hi%20Coach%20%F0%9F%91%8B%20I%20want%20to%20start%20online%20coaching.", // e.g. "https://wa.me/1234567890?text=Hi%20Coach%20..."
  // Optional: replace pricing buttons with real checkout links:
  checkout: {
    trial: "",    // e.g. "https://buy.stripe.com/..."
    monthly: "",
    yearly: "",
    instagram: ""
  }
};

// ------------------------------
// DOM
// ------------------------------
const yearEl = $("#year");
if (yearEl) yearEl.textContent = new Date().getFullYear();

const form = $("#planForm");
const msg = $("#formMsg");
const output = $("#output");
const summaryCard = $("#summaryCard");
const nutritionCard = $("#nutritionCard");
const trainingCard = $("#trainingCard");
const mealCard = $("#mealCard");
const resetBtn = $("#resetBtn");
const printBtn = $("#printBtn");
const copyBtn = $("#copyBtn");

const genderEl = $("#gender");
const heroMale = $("#heroMale");
const heroFemale = $("#heroFemale");
const heroBadge = $("#heroBadge");

const shareBtn = $("#shareBtn");
const copyLinkBtn = $("#copyLinkBtn");

// Tracker
const trackDate = $("#trackDate");
const foodSelect = $("#foodSelect");
const foodQty = $("#foodQty");
const qtyHint = $("#qtyHint");
const trackForm = $("#trackForm");
const trackMsg = $("#trackMsg");
const logBody = $("#logBody");
const clearDayBtn = $("#clearDayBtn");

const trackerKpis = $("#trackerKpis");
const calProgressText = $("#calProgressText");
const calBar = $("#calBar");
const pBar = $("#pBar");
const cBar = $("#cBar");
const fBar = $("#fBar");

// Contact
const coachEmailLink = $("#coachEmailLink");
const coachIgLink = $("#coachIgLink");
const coachWaLink = $("#coachWaLink");
const contactForm = $("#contactForm");
const leadName = $("#leadName");
const leadEmail = $("#leadEmail");
const leadMsg = $("#leadMsg");
const leadStatus = $("#leadStatus");
const fillLeadExample = $("#fillLeadExample");

// Modal
const modal = $("#modal");
const modalTitle = $("#modalTitle");
const modalBody = $("#modalBody");
const modalPrimary = $("#modalPrimary");
const openPaymentHelp = $("#openPaymentHelp");

// ------------------------------
// Helpers
// ------------------------------
function clamp(n, min, max){ return Math.max(min, Math.min(max, n)); }
function roundTo(n, step){ return Math.round(n / step) * step; }
function fmt(n){ return new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 }).format(n); }
function fmt1(n){ return new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(n); }

function escapeHtml(str){
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function goalLabel(goal){
  if (goal === "lose") return "Lose weight (cut)";
  if (goal === "gain") return "Gain weight (bigger surplus)";
  return "Build muscle (lean bulk)";
}

function dietLabel(diet){
  if (diet === "halal") return "Halal-friendly";
  if (diet === "vegetarian") return "Vegetarian";
  return "No preference";
}

function activityLabel(x){
  if (x === "sedentary") return "Sedentary";
  if (x === "active") return "Active";
  return "Normal";
}

// ------------------------------
// Calorie math
// ------------------------------
function mifflinBmr({sex, weightKg, heightCm, age}){
  const base = (10 * weightKg) + (6.25 * heightCm) - (5 * age);
  return sex === "male" ? base + 5 : base - 161;
}

function activityFactorFromDays(days){
  // gym days adds to activity, then we adjust with outside activity choice later
  if (days <= 3) return 1.45;
  if (days === 4) return 1.55;
  if (days === 5) return 1.65;
  return 1.75; // 6 days
}

function outsideActivityMultiplier(outside){
  if (outside === "sedentary") return 0.95;
  if (outside === "active") return 1.08;
  return 1.00;
}

function calcTargetCalories({goal, tdee, sex}){
  // Conservative floors.
  const floor = sex === "female" ? 1200 : 1500;

  if (goal === "lose"){
    const target = Math.round(tdee * 0.80);
    return clamp(target, floor, 4500);
  }
  if (goal === "gain"){
    const surplus = clamp(Math.round(tdee * 0.15), 350, 700);
    return clamp(Math.round(tdee + surplus), floor + 200, 6000);
  }
  // build (lean bulk)
  const surplus = clamp(Math.round(tdee * 0.10), 150, 400);
  return clamp(Math.round(tdee + surplus), floor + 200, 5600);
}

function calcMacros({goal, calories, weightKg}){
  let proteinPerKg = 2.0;
  let fatPerKg = 0.8;

  if (goal === "lose"){
    proteinPerKg = 2.2;
    fatPerKg = 0.7;
  } else if (goal === "gain"){
    proteinPerKg = 1.8;
    fatPerKg = 0.9;
  } else { // build
    proteinPerKg = 2.0;
    fatPerKg = 0.8;
  }

  const protein = roundTo(proteinPerKg * weightKg, 5);
  const fat = roundTo(fatPerKg * weightKg, 5);

  const kcalFromProtein = protein * 4;
  const kcalFromFat = fat * 9;
  const remaining = Math.max(0, calories - kcalFromProtein - kcalFromFat);
  const carbs = roundTo(remaining / 4, 5);

  return { protein, fat, carbs };
}

// ------------------------------
// Training templates
// ------------------------------
function trainingTemplates(goal, days){
  // Goal-based + days/week; each day has exercises with sets/reps.
  // NOTE: You can replace these with your own library.

  // 3 days = full body
  const fullBody = [
    { day: "Day 1", focus: "Full Body A", items: [
      ex("Back Squat (or Leg Press)", "4", "6–10"),
      ex("Bench Press (or DB Press)", "4", "6–10"),
      ex("Chest-Supported Row", "4", "8–12"),
      ex("Romanian Deadlift", "3", "6–10"),
      ex("Lateral Raise", "3", "12–20"),
      ex("Plank", "3", "45–75s"),
    ]},
    { day: "Day 2", focus: "Full Body B", items: [
      ex("Deadlift (or Trap Bar)", "3", "3–5"),
      ex("Incline DB Press", "4", "8–12"),
      ex("Lat Pulldown / Pull-ups", "4", "6–12"),
      ex("Leg Press", "3", "10–15"),
      ex("Leg Curl", "3", "10–15"),
      ex("DB Curl", "3", "10–15"),
    ]},
    { day: "Day 3", focus: "Full Body C", items: [
      ex("Front Squat (or Hack Squat)", "4", "6–10"),
      ex("Overhead Press", "3", "6–10"),
      ex("Seated Cable Row", "4", "8–12"),
      ex("Hip Thrust", "3", "8–12"),
      ex("Triceps Pushdown", "3", "10–15"),
      ex("Hanging Knee Raise", "3", "10–15"),
    ]},
  ];

  // 4 days = upper/lower
  const upperLower = [
    { day: "Day 1", focus: "Upper (strength + size)", items: [
      ex("Bench Press", "4", "5–8"),
      ex("Row (cable or barbell)", "4", "6–10"),
      ex("Overhead Press", "3", "6–10"),
      ex("Lat Pulldown / Pull-ups", "3", "8–12"),
      ex("Lateral Raise", "3", "12–20"),
      ex("Triceps Pushdown", "2–3", "10–15"),
    ]},
    { day: "Day 2", focus: "Lower (strength + size)", items: [
      ex("Back Squat", "4", "5–8"),
      ex("Romanian Deadlift", "3", "6–10"),
      ex("Leg Press", "3", "10–15"),
      ex("Leg Curl", "3", "10–15"),
      ex("Calf Raise", "4", "10–20"),
      ex("Core (plank/deadbug)", "3", "8–15"),
    ]},
    { day: "Day 3", focus: "Upper (hypertrophy)", items: [
      ex("Incline Press", "4", "8–12"),
      ex("Seated Row", "4", "8–12"),
      ex("Lat Pulldown", "3", "10–12"),
      ex("Lateral Raise", "4", "12–20"),
      ex("Face Pull", "3", "12–20"),
      ex("Biceps Curl", "3", "10–15"),
    ]},
    { day: "Day 4", focus: "Lower (hypertrophy)", items: [
      ex("Front Squat / Hack Squat", "4", "8–12"),
      ex("Hip Thrust", "3", "8–12"),
      ex("Bulgarian Split Squat", "3", "8–12/leg"),
      ex("Leg Curl", "3", "10–15"),
      ex("Calf Raise", "4", "10–20"),
      ex("Hanging Knee Raise", "3", "10–15"),
    ]},
  ];

  // 5/6 days: PPL-based
  const ppl5 = [
    { day: "Day 1", focus: "Push", items: [
      ex("Bench Press", "4", "6–10"),
      ex("Incline DB Press", "3", "8–12"),
      ex("Overhead Press", "3", "6–10"),
      ex("Lateral Raise", "4", "12–20"),
      ex("Triceps Pushdown", "3", "10–15"),
    ]},
    { day: "Day 2", focus: "Pull", items: [
      ex("Pull-ups / Lat Pulldown", "4", "6–12"),
      ex("Barbell/Cable Row", "4", "6–12"),
      ex("Rear Delt Fly", "3", "12–20"),
      ex("Face Pull", "3", "12–20"),
      ex("DB Curl", "3", "10–15"),
    ]},
    { day: "Day 3", focus: "Legs", items: [
      ex("Squat (or Hack Squat)", "4", "6–10"),
      ex("Romanian Deadlift", "4", "8–12"),
      ex("Leg Press", "3", "10–15"),
      ex("Leg Curl", "3", "10–15"),
      ex("Calf Raise", "4", "12–20"),
      ex("Core", "3", "10–15"),
    ]},
    { day: "Day 4", focus: "Upper (volume)", items: [
      ex("Incline Press", "4", "8–12"),
      ex("Seated Row", "4", "8–12"),
      ex("Lat Pulldown (alt grip)", "3", "10–12"),
      ex("Lateral Raise", "3–4", "12–20"),
      ex("Triceps Extension", "3", "10–15"),
      ex("Biceps Curl", "3", "10–15"),
    ]},
    { day: "Day 5", focus: "Lower (glute/ham emphasis)", items: [
      ex("Front Squat (or Goblet)", "4", "8–12"),
      ex("Hip Thrust", "4", "8–12"),
      ex("Split Squat", "3", "8–12/leg"),
      ex("Leg Curl", "3", "12–15"),
      ex("Calf Raise", "3", "12–20"),
      ex("Cable Crunch", "3", "10–15"),
    ]},
  ];

  const ppl6 = [
    ...ppl5.slice(0,3),
    { day: "Day 4", focus: "Push (variation)", items: [
      ex("Incline Press", "4", "8–12"),
      ex("DB Bench", "3", "8–12"),
      ex("Machine Shoulder Press", "3", "10–12"),
      ex("Cable Fly", "2–3", "12–20"),
      ex("Triceps Extension", "3", "10–15"),
    ]},
    { day: "Day 5", focus: "Pull (variation)", items: [
      ex("Lat Pulldown", "4", "8–12"),
      ex("Seated Row", "4", "8–12"),
      ex("Single-arm Row", "2", "10–12/side"),
      ex("Rear Delt Fly", "3", "12–20"),
      ex("Hammer Curl", "3", "10–15"),
    ]},
    { day: "Day 6", focus: "Legs (variation)", items: [
      ex("Hack Squat / Front Squat", "4", "8–12"),
      ex("Romanian Deadlift", "3", "8–12"),
      ex("Leg Extension", "3", "12–15"),
      ex("Leg Curl", "3", "10–15"),
      ex("Calf Raise", "4", "12–20"),
      ex("Core", "3", "10–15"),
    ]},
  ];

  const mapByDays = { 3: fullBody, 4: upperLower, 5: ppl5, 6: ppl6 };
  let plan = mapByDays[days] || upperLower;

  // Goal tweaks
  if (goal === "lose"){
    plan = plan.map(d => ({
      ...d,
      focus: d.focus + " (cut)",
      items: d.items
    }));
    // Add cardio suggestion as extra day note (displayed in training card)
  }
  if (goal === "gain"){
    plan = plan.map(d => ({
      ...d,
      focus: d.focus + " (gain)",
      items: d.items
    }));
  }

  return plan;
}

function ex(name, sets, reps){ return { ex: name, sets, reps }; }

// ------------------------------
// Food database (approx values)
// NOTE: Nutrition varies by brand/cooking method. Use as guidance.
// ------------------------------
const FOOD_DB = {
  egg: { key: "egg", name: "Egg (whole)", unit: "egg", perUnit: { kcal: 72, p: 6.3, c: 0.4, f: 4.8 } },
  bread: { key: "bread", name: "Whole wheat bread", unit: "g", per100g: { kcal: 247, p: 13, c: 41, f: 4 } },
  oats: { key: "oats", name: "Oats (dry)", unit: "g", per100g: { kcal: 389, p: 17, c: 66, f: 7 } },
  yogurt: { key: "yogurt", name: "Greek yogurt (0%)", unit: "g", per100g: { kcal: 59, p: 10, c: 3.6, f: 0.4 } },
  banana: { key: "banana", name: "Banana", unit: "g", per100g: { kcal: 89, p: 1.1, c: 23, f: 0.3 } },
  berries: { key: "berries", name: "Berries", unit: "g", per100g: { kcal: 50, p: 1, c: 12, f: 0.2 } },
  honey: { key: "honey", name: "Honey", unit: "g", per100g: { kcal: 304, p: 0.3, c: 82, f: 0 } },

  chicken: { key: "chicken", name: "Chicken breast (cooked)", unit: "g", per100g: { kcal: 165, p: 31, c: 0, f: 3.6 } },
  turkey: { key: "turkey", name: "Turkey breast (cooked)", unit: "g", per100g: { kcal: 135, p: 29, c: 0, f: 1.5 } },
  beef: { key: "beef", name: "Lean beef (10%)", unit: "g", per100g: { kcal: 217, p: 26, c: 0, f: 12 } },
  salmon: { key: "salmon", name: "Salmon", unit: "g", per100g: { kcal: 208, p: 20, c: 0, f: 13 } },
  tuna: { key: "tuna", name: "Tuna (canned, water)", unit: "g", per100g: { kcal: 116, p: 26, c: 0, f: 1 } },
  tofu: { key: "tofu", name: "Tofu (firm)", unit: "g", per100g: { kcal: 144, p: 15, c: 3, f: 9 } },

  rice: { key: "rice", name: "Rice (cooked)", unit: "g", per100g: { kcal: 130, p: 2.7, c: 28, f: 0.3 } },
  pasta: { key: "pasta", name: "Pasta (cooked)", unit: "g", per100g: { kcal: 158, p: 5.8, c: 30, f: 0.9 } },
  potato: { key: "potato", name: "Potatoes (boiled)", unit: "g", per100g: { kcal: 87, p: 2, c: 20, f: 0.1 } },

  almonds: { key: "almonds", name: "Almonds", unit: "g", per100g: { kcal: 579, p: 21, c: 22, f: 50 } },
  peanutButter: { key: "peanutButter", name: "Peanut butter", unit: "g", per100g: { kcal: 588, p: 25, c: 20, f: 50 } },
  oliveOil: { key: "oliveOil", name: "Olive oil", unit: "g", per100g: { kcal: 884, p: 0, c: 0, f: 100 } },

  veg: { key: "veg", name: "Vegetables (mixed)", unit: "g", per100g: { kcal: 35, p: 2, c: 7, f: 0.2 } },

  custom: { key: "custom", name: "Custom calories (manual)", unit: "portion", custom: true },
};

function calcFoodMacros(foodKey, qty){
  const f = FOOD_DB[foodKey];
  if (!f) return { kcal: 0, p: 0, c: 0, f: 0 };

  if (f.custom) return { kcal: 0, p: 0, c: 0, f: 0 };

  if (f.perUnit){
    const q = qty; // units
    return {
      kcal: f.perUnit.kcal * q,
      p: f.perUnit.p * q,
      c: f.perUnit.c * q,
      f: f.perUnit.f * q,
    };
  }
  // grams
  const factor = qty / 100;
  return {
    kcal: f.per100g.kcal * factor,
    p: f.per100g.p * factor,
    c: f.per100g.c * factor,
    f: f.per100g.f * factor,
  };
}

function roundFoodQty(qty, unit){
  if (unit === "egg") return clamp(Math.round(qty), 1, 8);
  return clamp(roundTo(qty, 5), 5, 2000);
}

// ------------------------------
// Weekly meal plan generator (7 days)
// Uses macro distribution + simple foods.
// ------------------------------
function distributeMacros(macros){
  // Percent distribution across 4 meals
  const dist = [
    { meal: "Breakfast", p: 0.25, c: 0.25, f: 0.25 },
    { meal: "Lunch",     p: 0.30, c: 0.35, f: 0.25 },
    { meal: "Snack",     p: 0.20, c: 0.10, f: 0.25 },
    { meal: "Dinner",    p: 0.25, c: 0.30, f: 0.25 },
  ];
  return dist.map(d => ({
    meal: d.meal,
    p: macros.protein * d.p,
    c: macros.carbs * d.c,
    f: macros.fat * d.f
  }));
}

function buildWeeklyMealPlan({goal, diet, macros}){
  // Meal blueprints per day for variety.
  // Each meal generator tries to meet distributed macro targets.
  const days = [
    { name: "Day 1", breakfast: "eggs", lunch: { protein:"chicken", carb:"rice" }, snack:"yogurt", dinner: { protein:"salmon", carb:"potato" } },
    { name: "Day 2", breakfast: "oats", lunch: { protein:"turkey", carb:"pasta" }, snack:"yogurt", dinner: { protein:"beef", carb:"rice" } },
    { name: "Day 3", breakfast: "eggs", lunch: { protein:"tuna", carb:"potato" }, snack:"yogurt", dinner: { protein:"chicken", carb:"pasta" } },
    { name: "Day 4", breakfast: "oats", lunch: { protein:"salmon", carb:"rice" }, snack:"yogurt", dinner: { protein:"turkey", carb:"potato" } },
    { name: "Day 5", breakfast: "eggs", lunch: { protein:"beef", carb:"rice" }, snack:"yogurt", dinner: { protein:"tuna", carb:"pasta" } },
    { name: "Day 6", breakfast: "oats", lunch: { protein:"chicken", carb:"potato" }, snack:"yogurt", dinner: { protein:"salmon", carb:"pasta" } },
    { name: "Day 7", breakfast: "eggs", lunch: { protein:"turkey", carb:"rice" }, snack:"yogurt", dinner: { protein:"chicken", carb:"potato" } },
  ];

  // Diet adjustments
  // - Vegetarian: replace animal proteins with tofu; keep eggs optional but we keep them (ovo-veg).
  // - Halal: just avoid pork/alcohol (already), and keep meat choices ok.
  const mapProtein = (p) => {
    if (diet === "vegetarian"){
      if (p === "tuna" || p === "salmon" || p === "beef" || p === "chicken" || p === "turkey") return "tofu";
    }
    return p;
  };

  const dist = distributeMacros(macros);

  return days.map((d) => {
    const meals = [];

    // Breakfast
    const bTarget = dist.find(x => x.meal === "Breakfast");
    meals.push(makeBreakfast(d.breakfast, bTarget, goal));

    // Lunch
    const lTarget = dist.find(x => x.meal === "Lunch");
    meals.push(makeMainMeal("Lunch", { protein: mapProtein(d.lunch.protein), carb: d.lunch.carb }, lTarget));

    // Snack
    const sTarget = dist.find(x => x.meal === "Snack");
    meals.push(makeSnack(sTarget, goal));

    // Dinner
    const dTarget = dist.find(x => x.meal === "Dinner");
    meals.push(makeMainMeal("Dinner", { protein: mapProtein(d.dinner.protein), carb: d.dinner.carb }, dTarget));

    // Add veggies suggestion
    return { day: d.name, meals, note: "Add vegetables/salad freely (aim 200–400g/day). Hydrate + salt meals for performance." };
  });
}

function makeBreakfast(type, target, goal){
  if (type === "oats"){
    // Oats + yogurt + berries + honey (+ almonds if needed)
    let oatsG = roundFoodQty(target.c * 0.6 / FOOD_DB.oats.per100g.c * 100, "g");
    let yogurtG = roundFoodQty(target.p / FOOD_DB.yogurt.per100g.p * 100, "g");
    let berriesG = 150; // fixed
    let honeyG = goal === "gain" ? 20 : 10;

    // fats
    const macrosSoFar =
      sumMacros([
        { key:"oats", qty:oatsG },
        { key:"yogurt", qty:yogurtG },
        { key:"berries", qty:berriesG },
        { key:"honey", qty:honeyG },
      ]);

    let fatNeed = target.f - macrosSoFar.f;
    let almondsG = 0;
    if (fatNeed > 3){
      almondsG = roundFoodQty((fatNeed / FOOD_DB.almonds.per100g.f) * 100, "g");
      almondsG = clamp(almondsG, 10, 35);
    }

    return {
      name: "Breakfast",
      title: "Oats bowl",
      items: [
        item("Oats", "oats", oatsG),
        item("Greek yogurt (0%)", "yogurt", yogurtG),
        item("Berries", "berries", berriesG),
        item("Honey", "honey", honeyG),
        ...(almondsG ? [item("Almonds", "almonds", almondsG)] : []),
      ]
    };
  }

  // Eggs + bread + banana (+ peanut butter if needed)
  const bananaCarb = Math.min(target.c * 0.40, 30);
  const bananaG = roundFoodQty(bananaCarb / FOOD_DB.banana.per100g.c * 100, "g");
  const breadCarb = Math.max(0, target.c - (bananaG / 100) * FOOD_DB.banana.per100g.c);
  let breadG = roundFoodQty(breadCarb / FOOD_DB.bread.per100g.c * 100, "g");
  breadG = clamp(breadG, 50, 140);

  let eggs = Math.round((target.p * 0.80) / FOOD_DB.egg.perUnit.p);
  eggs = clamp(eggs, goal === "lose" ? 2 : 3, 6);

  const macrosSoFar = sumMacros([
    { key:"egg", qty:eggs, unit:"egg" },
    { key:"bread", qty:breadG },
    { key:"banana", qty:bananaG }
  ]);

  // If protein still short, add yogurt
  let pNeed = target.p - macrosSoFar.p;
  let yogurtG = 0;
  if (pNeed > 5){
    yogurtG = roundFoodQty((pNeed / FOOD_DB.yogurt.per100g.p) * 100, "g");
    yogurtG = clamp(yogurtG, 100, 250);
  }

  const macrosAfterYogurt = sumMacros([
    { key:"egg", qty:eggs, unit:"egg" },
    { key:"bread", qty:breadG },
    { key:"banana", qty:bananaG },
    ...(yogurtG ? [{ key:"yogurt", qty:yogurtG }] : [])
  ]);

  // fats top-up with peanut butter
  let fatNeed = target.f - macrosAfterYogurt.f;
  let pbG = 0;
  if (fatNeed > 4 && goal !== "lose"){
    pbG = roundFoodQty((fatNeed / FOOD_DB.peanutButter.per100g.f) * 100, "g");
    pbG = clamp(pbG, 10, 30);
  }

  return {
    name: "Breakfast",
    title: "Eggs + toast",
    items: [
      item("Eggs", "egg", eggs, "egg"),
      item("Whole wheat bread", "bread", breadG),
      item("Banana", "banana", bananaG),
      ...(yogurtG ? [item("Greek yogurt (0%)", "yogurt", yogurtG)] : []),
      ...(pbG ? [item("Peanut butter", "peanutButter", pbG)] : []),
    ]
  };
}

function makeMainMeal(mealName, combo, target){
  const pKey = combo.protein;
  const cKey = combo.carb;
  const vegG = 200;

  // Protein grams from protein target
  let proteinG = roundFoodQty((target.p / FOOD_DB[pKey].per100g.p) * 100, "g");
  proteinG = clamp(proteinG, 120, 320);

  // Carb grams from carb target
  let carbG = roundFoodQty((target.c / FOOD_DB[cKey].per100g.c) * 100, "g");
  // Keep realistic bounds
  carbG = clamp(carbG, cKey === "potato" ? 250 : 180, cKey === "potato" ? 650 : 520);

  // Fats: add olive oil if needed
  const baseMacros = sumMacros([
    { key:pKey, qty:proteinG },
    { key:cKey, qty:carbG },
    { key:"veg", qty:vegG }
  ]);
  let fatNeed = target.f - baseMacros.f;
  let oilG = 0;
  if (fatNeed > 2){
    oilG = roundTo(fatNeed, 1); // olive oil fat ≈ grams
    oilG = clamp(oilG, 0, 20);
  }

  return {
    name: mealName,
    title: `${FOOD_DB[pKey].name} + ${FOOD_DB[cKey].name}`,
    items: [
      item(FOOD_DB[pKey].name, pKey, proteinG),
      item(FOOD_DB[cKey].name, cKey, carbG),
      item("Vegetables / salad", "veg", vegG),
      ...(oilG ? [item("Olive oil", "oliveOil", oilG)] : []),
    ]
  };
}

function makeSnack(target, goal){
  // Yogurt + almonds + fruit
  let yogurtG = roundFoodQty((target.p / FOOD_DB.yogurt.per100g.p) * 100, "g");
  yogurtG = clamp(yogurtG, 150, 350);

  const bananaCarb = Math.min(target.c, 25);
  let bananaG = roundFoodQty((bananaCarb / FOOD_DB.banana.per100g.c) * 100, "g");
  bananaG = clamp(bananaG, 80, 160);

  const macrosSoFar = sumMacros([
    { key:"yogurt", qty:yogurtG },
    { key:"banana", qty:bananaG }
  ]);
  let fatNeed = target.f - macrosSoFar.f;
  let almondsG = 0;
  if (fatNeed > 3){
    almondsG = roundFoodQty((fatNeed / FOOD_DB.almonds.per100g.f) * 100, "g");
    almondsG = clamp(almondsG, goal === "lose" ? 10 : 15, 35);
  }

  return {
    name: "Snack",
    title: "Yogurt + fruit",
    items: [
      item("Greek yogurt (0%)", "yogurt", yogurtG),
      item("Banana", "banana", bananaG),
      ...(almondsG ? [item("Almonds", "almonds", almondsG)] : []),
    ]
  };
}

function item(label, key, qty, unitOverride){
  const unit = unitOverride || FOOD_DB[key].unit;
  return { label, key, qty, unit };
}

function sumMacros(list){
  const total = { kcal: 0, p: 0, c: 0, f: 0 };
  for (const x of list){
    const food = FOOD_DB[x.key];
    if (!food) continue;
    if (food.perUnit){
      const m = calcFoodMacros(x.key, x.qty);
      total.kcal += m.kcal; total.p += m.p; total.c += m.c; total.f += m.f;
    } else {
      const m = calcFoodMacros(x.key, x.qty);
      total.kcal += m.kcal; total.p += m.p; total.c += m.c; total.f += m.f;
    }
  }
  return total;
}

// ------------------------------
// Rendering — Generator
// ------------------------------
function buildWorkoutTable(days){
  const rows = days.map(d => {
    const list = d.items.map(i => {
      return `<div><strong>${escapeHtml(i.ex)}</strong> — ${escapeHtml(i.sets)} × ${escapeHtml(i.reps)}</div>`;
    }).join("");
    return `
      <tr>
        <td><strong>${escapeHtml(d.day)}</strong><div class="micro">${escapeHtml(d.focus)}</div></td>
        <td>${list}</td>
      </tr>
    `;
  }).join("");

  return `
    <div class="table-wrap">
      <table class="table" role="table">
        <thead><tr><th style="width: 170px;">Day</th><th>Session</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `;
}

function renderMealPlan(week, macros){
  // Collapsible 7-day plan
  const daysHtml = week.map((d, idx) => {
    const mealsHtml = d.meals.map(m => {
      const itemsHtml = m.items.map(it => {
        const unit = it.unit === "egg" ? "eggs" : "g";
        return `<li><strong>${escapeHtml(it.label)}:</strong> ${fmt1(it.qty)} ${escapeHtml(unit)}</li>`;
      }).join("");
      return `
        <div>
          <div><strong>${escapeHtml(m.name)}:</strong> <span class="muted">${escapeHtml(m.title)}</span></div>
          <ul class="clean">${itemsHtml}</ul>
        </div>
      `;
    }).join("");

    return `
      <details ${idx === 0 ? "open" : ""} class="advanced">
        <summary><strong>${escapeHtml(d.day)}</strong> <span class="micro muted">— variety day</span></summary>
        <div class="micro muted" style="margin: 8px 0 10px;">${escapeHtml(d.note)}</div>
        ${mealsHtml}
      </details>
    `;
  }).join("");

  return `
    <h3>7-day weekly food program (exact portions)</h3>
    <p class="muted">
      Daily macros target: <strong>${fmt(Math.round(macros.protein))}g protein</strong>,
      <strong>${fmt(Math.round(macros.carbs))}g carbs</strong>,
      <strong>${fmt(Math.round(macros.fat))}g fats</strong>.
      Portions below are estimates—adjust based on weekly progress.
    </p>
    ${daysHtml}
    <hr class="sep" />
    <p class="micro">
      If progress stalls for 14 days: adjust calories by <strong>±150–250 kcal/day</strong>.
      Cutting: down. Bulking: up.
    </p>
  `;
}

function renderPlan(data){
  const { age, weightKg, heightCm, goal, sex, days, outsideActivity, diet, tdee, targetCalories, macros, weeklyMeals } = data;

  const bmi = weightKg / Math.pow(heightCm / 100, 2);
  const bmiTxt = Number.isFinite(bmi) ? bmi.toFixed(1) : "—";

  summaryCard.innerHTML = `
    <h3>Summary</h3>
    <div class="badge">Goal: <strong>${escapeHtml(goalLabel(goal))}</strong></div>

    <div class="kpis">
      <div class="kpi"><div class="label">Estimated maintenance</div><div class="value">${fmt(Math.round(tdee))} kcal</div></div>
      <div class="kpi"><div class="label">Target calories</div><div class="value">${fmt(Math.round(targetCalories))} kcal</div></div>
      <div class="kpi"><div class="label">BMI (rough)</div><div class="value">${bmiTxt}</div></div>
    </div>

    <hr class="sep" />

    <div class="micro">
      Inputs: age ${age}, ${weightKg.toFixed(1)} kg, ${heightCm.toFixed(1)} cm • gender: ${sex} • days/week: ${days} • activity: ${escapeHtml(activityLabel(outsideActivity))} • diet: ${escapeHtml(dietLabel(diet))}
    </div>
  `;

  nutritionCard.innerHTML = `
    <h3>Nutrition targets</h3>
    <p><strong>Calories:</strong> ${fmt(Math.round(targetCalories))} kcal/day</p>

    <div class="kpis">
      <div class="kpi"><div class="label">Protein</div><div class="value">${fmt(Math.round(macros.protein))} g</div></div>
      <div class="kpi"><div class="label">Carbs</div><div class="value">${fmt(Math.round(macros.carbs))} g</div></div>
      <div class="kpi"><div class="label">Fats</div><div class="value">${fmt(Math.round(macros.fat))} g</div></div>
    </div>

    <hr class="sep" />

    <ul class="clean">
      <li><strong>Protein first:</strong> hit your protein target daily.</li>
      <li><strong>Carbs around training:</strong> more carbs before/after workouts.</li>
      <li><strong>Hydrate + salt meals</strong> for performance and pumps.</li>
    </ul>

    <p class="micro">
      These are estimates based on limited inputs. Real results depend on sleep, steps, consistency, and training quality.
    </p>
  `;

  mealCard.innerHTML = renderMealPlan(weeklyMeals, macros);

  const plan = trainingTemplates(goal, days);

  trainingCard.innerHTML = `
    <h3>Gym split</h3>
    <p><strong>${escapeHtml(days)} days/week</strong> • <span class="micro muted">progressive overload focused</span></p>
    ${buildWorkoutTable(plan)}
    <hr class="sep" />
    <h4 style="margin:0 0 8px;">Progress rules</h4>
    <ul class="clean">
      <li>Keep 1–2 reps in reserve on compounds; push closer to failure on last accessory set.</li>
      <li>When you reach the top of the rep range for all sets: add 2.5–5% weight next session.</li>
      <li>Deload every 6–10 weeks if performance stalls.</li>
      ${goal === "lose" ? "<li>Cut tip: add 8k–12k steps/day and 2× zone 2 cardio sessions (20–40 min).</li>" : ""}
    </ul>
  `;

  output.hidden = false;
  output.scrollIntoView({behavior: "smooth", block: "start"});
}

// ------------------------------
// Validation + storage
// ------------------------------
function validateInputs({age, weight, height, sex, days}){
  const errors = [];
  if (!Number.isFinite(age) || age < 13 || age > 90) errors.push("Enter a valid age (13–90).");
  if (!sex) errors.push("Select gender.");
  if (!Number.isFinite(weight) || weight < 30 || weight > 250) errors.push("Enter a valid weight in kg (30–250).");
  if (!Number.isFinite(height) || height < 130 || height > 220) errors.push("Enter a valid height in cm (130–220).");
  if (![3,4,5,6].includes(days)) errors.push("Select training days/week.");
  return errors;
}

function saveLastPlan(data){
  try { localStorage.setItem("a2_last_plan_v2", JSON.stringify(data)); } catch(e) {}
}
function loadLastPlan(){
  try {
    const raw = localStorage.getItem("a2_last_plan_v2");
    return raw ? JSON.parse(raw) : null;
  } catch(e){ return null; }
}

function makeSummaryText(plan){
  return [
    "abd2uhyouronlinecoach — Plan Summary",
    `Gender: ${plan.sex} | Age: ${plan.age} | Weight: ${plan.weightKg.toFixed(1)} kg | Height: ${plan.heightCm.toFixed(1)} cm`,
    `Goal: ${goalLabel(plan.goal)} | Days/week: ${plan.days} | Diet: ${dietLabel(plan.diet)}`,
    `Calories: ${Math.round(plan.targetCalories)} kcal/day`,
    `Macros: Protein ${Math.round(plan.macros.protein)}g, Carbs ${Math.round(plan.macros.carbs)}g, Fats ${Math.round(plan.macros.fat)}g`,
    "",
    "Weekly meal plan and training split are on the page."
  ].join("\n");
}

// ------------------------------
// Gender image switch
// ------------------------------
function setHeroByGender(sex){
  if (!sex){
    heroBadge.textContent = "Select gender to preview";
    heroMale.classList.add("is-active");
    heroFemale.classList.remove("is-active");
    return;
  }
  if (sex === "female"){
    heroBadge.textContent = "Female preview";
    heroFemale.classList.add("is-active");
    heroMale.classList.remove("is-active");
  } else {
    heroBadge.textContent = "Male preview";
    heroMale.classList.add("is-active");
    heroFemale.classList.remove("is-active");
  }
}

genderEl?.addEventListener("change", () => setHeroByGender(genderEl.value));

// ------------------------------
// Generator form events
// ------------------------------
form?.addEventListener("submit", (e) => {
  e.preventDefault();
  msg.textContent = "";

  const age = Number($("#age").value);
  const weight = Number($("#weight").value);
  const height = Number($("#height").value);
  const goal = $("#goal").value;
  const sex = $("#gender").value;
  const days = Number($("#days").value);
  const outsideActivity = $("#activity").value || "normal";
  const diet = $("#diet").value || "normal";

  const errors = validateInputs({age, weight, height, sex, days});
  if (errors.length){
    msg.textContent = errors.join(" ");
    return;
  }

  setHeroByGender(sex);

  const activityFactor = activityFactorFromDays(days) * outsideActivityMultiplier(outsideActivity);
  const bmr = mifflinBmr({sex, weightKg: weight, heightCm: height, age});
  const tdee = bmr * activityFactor;

  const targetCalories = calcTargetCalories({goal, tdee, sex});
  const macros = calcMacros({goal, calories: targetCalories, weightKg: weight});

  const weeklyMeals = buildWeeklyMealPlan({goal, diet, macros});

  const data = {
    age,
    weightKg: weight,
    heightCm: height,
    goal,
    sex,
    days,
    outsideActivity,
    diet,
    activityFactor,
    tdee,
    targetCalories,
    macros,
    weeklyMeals
  };

  saveLastPlan(data);
  renderPlan(data);
  refreshTrackerTargets();
});

resetBtn?.addEventListener("click", () => {
  form.reset();
  msg.textContent = "";
  output.hidden = true;
  setHeroByGender("");
  try { localStorage.removeItem("a2_last_plan_v2"); } catch(e){}
  refreshTrackerTargets();
});

printBtn?.addEventListener("click", () => window.print());

copyBtn?.addEventListener("click", async () => {
  const last = loadLastPlan();
  if (!last){
    msg.textContent = "Generate a plan first, then copy.";
    return;
  }
  const text = makeSummaryText(last);
  try{
    await navigator.clipboard.writeText(text);
    msg.textContent = "Copied summary to clipboard.";
  } catch(e){
    msg.textContent = "Could not access clipboard. Select text and copy manually.";
  }
});

// Auto-load last plan
(function init(){
  const last = loadLastPlan();
  if (!last) {
    refreshTrackerTargets();
    return;
  }

  $("#age").value = last.age ?? "";
  $("#weight").value = last.weightKg ?? "";
  $("#height").value = last.heightCm ?? "";
  $("#goal").value = last.goal ?? "build";
  $("#gender").value = last.sex ?? "";
  $("#days").value = String(last.days ?? 4);
  $("#activity").value = last.outsideActivity ?? "normal";
  $("#diet").value = last.diet ?? "normal";

  setHeroByGender(last.sex);
  renderPlan(last);
  refreshTrackerTargets();
})();

// ------------------------------
// Share buttons
// ------------------------------
async function shareSite(){
  const url = window.location.href;
  const title = "abd2uhyouronlinecoach";
  try{
    if (navigator.share){
      await navigator.share({ title, text: "Check out this gym coaching generator:", url });
      return;
    }
  }catch(e){}
  // fallback to copy
  await copyText(url);
  showModal("Link copied", `<p>Copied this link:</p><p><code>${escapeHtml(url)}</code></p>`);
}

async function copyText(text){
  try{
    await navigator.clipboard.writeText(text);
  } catch(e){
    // fallback
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
}

shareBtn?.addEventListener("click", shareSite);
copyLinkBtn?.addEventListener("click", async () => {
  const url = window.location.href;
  await copyText(url);
  showModal("Link copied", `<p>Copied this link:</p><p><code>${escapeHtml(url)}</code></p>`);
});

// ------------------------------
// Modal helpers
// ------------------------------
function showModal(title, html, primaryText = "OK", onPrimary = null){
  if (!modal) return;
  modalTitle.textContent = title;
  modalBody.innerHTML = html;
  modalPrimary.textContent = primaryText;
  modalPrimary.onclick = () => {
    try { onPrimary && onPrimary(); } finally { modal.close(); }
  };
  modal.showModal();
}

openPaymentHelp?.addEventListener("click", () => {
  showModal(
    "Connect payments",
    `
      <p>This template is static. To accept payments you can:</p>
      <ul class="clean">
        <li>Create Stripe Payment Links (trial/month/year/IG coaching).</li>
        <li>Or create PayPal “Buy Now” links.</li>
        <li>Paste those URLs into <code>script.js</code> → <code>COACH.checkout</code>, or replace the button actions.</li>
      </ul>
      <p class="micro">If you want, I can also convert this into a real web app with login + subscriptions.</p>
    `
  );
});

// ------------------------------
// Pricing buttons -> open email/checkout
// ------------------------------
document.querySelectorAll("[data-plan]")?.forEach((btn) => {
  btn.addEventListener("click", async () => {
    const plan = btn.getAttribute("data-plan") || "Subscription";
    const last = loadLastPlan();
    const url = window.location.href;

    // If checkout links exist, open them
    const planKey = "personal";

    if (planKey && COACH.checkout[planKey]){
      window.open(COACH.checkout[planKey], "_blank", "noreferrer");
      return;
    }

    // fallback: create mailto
    const subject = encodeURIComponent(`Subscription request: ${plan}`);
    const bodyLines = [
      `Hi Coach,`,
      ``,
      `I want to start: ${plan}`,
      ``,
      last ? `My stats: ${last.sex}, age ${last.age}, ${last.weightKg}kg, ${last.heightCm}cm` : `My stats: (not provided)`,
      last ? `Goal: ${goalLabel(last.goal)} | Days/week: ${last.days} | Diet: ${dietLabel(last.diet)}` : ``,
      last ? `Target calories: ${Math.round(last.targetCalories)} kcal/day` : ``,
      ``,
      `Website: ${url}`,
      ``,
      `Thanks!`
    ].filter(Boolean);

    const body = encodeURIComponent(bodyLines.join("\n"));
    const mailto = `mailto:${COACH.email}?subject=${subject}&body=${body}`;

    showModal(
      "Send your request",
      `
        <p><strong>${escapeHtml(plan)}</strong></p>
        <p>This is a static demo. Click below to open an email to the coach:</p>
        <p><a class="btn" href="${mailto}">Open email</a></p>
        <p class="micro">Or connect a real Stripe/PayPal link in <code>script.js</code>.</p>
      `
    );
  });
});

// ------------------------------
// Contact section wiring
// ------------------------------
function initContact(){
  if (coachEmailLink){
    coachEmailLink.textContent = COACH.email;
    coachEmailLink.href = `mailto:${COACH.email}`;
  }
  if (coachIgLink){
    coachIgLink.textContent = `@${COACH.instagramHandle}`;
    coachIgLink.href = `https://instagram.com/${COACH.instagramHandle}`;
  }
  if (coachWaLink){
    coachWaLink.href = COACH.whatsappUrl || "#";
    coachWaLink.textContent = COACH.whatsappUrl ? "Chat on WhatsApp" : "Add your link";
  }
}
initContact();

fillLeadExample?.addEventListener("click", () => {
  leadName.value = "Ahmed";
  leadEmail.value = "you@email.com";
  leadMsg.value = "Hi Coach! I want to start the monthly plan. My goal is to build muscle. I can train 4 days/week. No injuries. Diet: normal.";
});

contactForm?.addEventListener("submit", (e) => {
  e.preventDefault();
  leadStatus.textContent = "";

  const name = (leadName.value || "").trim();
  const email = (leadEmail.value || "").trim();
  const message = (leadMsg.value || "").trim();
  if (!name || !email || !message){
    leadStatus.textContent = "Please fill name, email, and message.";
    return;
  }

  const last = loadLastPlan();
  const subject = encodeURIComponent(`Client inquiry: ${name}`);
  const bodyLines = [
    `Name: ${name}`,
    `Email: ${email}`,
    ``,
    `Message:`,
    message,
    ``,
    last ? `Stats: ${last.sex}, age ${last.age}, ${last.weightKg}kg, ${last.heightCm}cm` : ``,
    last ? `Goal: ${goalLabel(last.goal)} | Days/week: ${last.days} | Diet: ${dietLabel(last.diet)}` : ``,
    last ? `Calories: ${Math.round(last.targetCalories)} kcal/day` : ``,
    ``,
    `Website: ${window.location.href}`
  ].filter(Boolean);

  const body = encodeURIComponent(bodyLines.join("\n"));
  const mailto = `mailto:${COACH.email}?subject=${subject}&body=${body}`;

  window.location.href = mailto;
  leadStatus.textContent = "Opening email…";
});

// ------------------------------
// Tracker: storage + UI
// ------------------------------
function isoToday(){
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const dd = String(d.getDate()).padStart(2,"0");
  return `${yyyy}-${mm}-${dd}`;
}

function trackerKey(dateStr){
  return `a2_tracker_${dateStr}`;
}

function loadLog(dateStr){
  try{
    const raw = localStorage.getItem(trackerKey(dateStr));
    return raw ? JSON.parse(raw) : [];
  }catch(e){ return []; }
}

function saveLog(dateStr, items){
  try{
    localStorage.setItem(trackerKey(dateStr), JSON.stringify(items));
  }catch(e){}
}

function uid(){
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

function populateFoodSelect(){
  const keys = Object.keys(FOOD_DB);
  // custom at bottom
  const sorted = keys.filter(k => k !== "custom").sort((a,b) => FOOD_DB[a].name.localeCompare(FOOD_DB[b].name));
  sorted.push("custom");

  foodSelect.innerHTML = sorted.map(k => {
    const f = FOOD_DB[k];
    return `<option value="${escapeHtml(k)}">${escapeHtml(f.name)}</option>`;
  }).join("");

  updateQtyHint();
}

function updateQtyHint(){
  const key = foodSelect.value;
  const f = FOOD_DB[key];
  if (!f) return;
  if (f.custom){
    qtyHint.textContent = "Use Custom calories fields (Quantity = 1)";
    foodQty.value = "1";
  } else if (f.unit === "egg"){
    qtyHint.textContent = "number of eggs (e.g. 3)";
    foodQty.placeholder = "e.g. 3";
  } else {
    qtyHint.textContent = "grams (e.g. 200)";
    foodQty.placeholder = "e.g. 200";
  }
}

foodSelect?.addEventListener("change", updateQtyHint);

function calcTotals(items){
  return items.reduce((acc, it) => {
    acc.kcal += it.kcal;
    acc.p += it.p;
    acc.c += it.c;
    acc.f += it.f;
    return acc;
  }, { kcal: 0, p: 0, c: 0, f: 0 });
}

function refreshTrackerTargets(){
  const last = loadLastPlan();
  const targets = last ? {
    kcal: last.targetCalories,
    p: last.macros.protein,
    c: last.macros.carbs,
    f: last.macros.fat
  } : null;

  // KPIs
  if (trackerKpis){
    trackerKpis.innerHTML = targets ? `
      <div class="kpi"><div class="label">Target kcal</div><div class="value">${fmt(Math.round(targets.kcal))}</div></div>
      <div class="kpi"><div class="label">Protein</div><div class="value">${fmt(Math.round(targets.p))}g</div></div>
      <div class="kpi"><div class="label">Carbs</div><div class="value">${fmt(Math.round(targets.c))}g</div></div>
    ` : `
      <div class="kpi"><div class="label">Target kcal</div><div class="value">—</div></div>
      <div class="kpi"><div class="label">Protein</div><div class="value">—</div></div>
      <div class="kpi"><div class="label">Carbs</div><div class="value">—</div></div>
    `;
  }

  // Apply to progress bars using current date log
  const dateStr = trackDate.value || isoToday();
  const items = loadLog(dateStr);
  renderLog(items, targets);
}

function renderLog(items, targets){
  // table
  if (!items.length){
    logBody.innerHTML = `<tr><td colspan="7" class="muted">No items yet.</td></tr>`;
  } else {
    logBody.innerHTML = items.map(it => `
      <tr>
        <td>${escapeHtml(it.name)}</td>
        <td>${escapeHtml(it.qtyLabel)}</td>
        <td>${fmt(Math.round(it.kcal))}</td>
        <td>${fmt1(it.p)}</td>
        <td>${fmt1(it.c)}</td>
        <td>${fmt1(it.f)}</td>
        <td><button class="btn btn-ghost" data-del="${escapeHtml(it.id)}" type="button">×</button></td>
      </tr>
    `).join("");

    // delete handlers
    logBody.querySelectorAll("[data-del]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-del");
        const dateStr = trackDate.value || isoToday();
        const arr = loadLog(dateStr).filter(x => x.id !== id);
        saveLog(dateStr, arr);
        refreshTrackerTargets();
      });
    });
  }

  const totals = calcTotals(items);

  if (!targets){
    calProgressText.textContent = "Generate a plan to see targets.";
    calBar.style.width = "0%";
    pBar.style.width = "0%";
    cBar.style.width = "0%";
    fBar.style.width = "0%";
    return;
  }

  const calPct = clamp((totals.kcal / targets.kcal) * 100, 0, 150);
  calBar.style.width = `${calPct}%`;

  const pPct = clamp((totals.p / targets.p) * 100, 0, 150);
  const cPct = clamp((totals.c / targets.c) * 100, 0, 150);
  const fPct = clamp((totals.f / targets.f) * 100, 0, 150);

  pBar.style.width = `${pPct}%`;
  cBar.style.width = `${cPct}%`;
  fBar.style.width = `${fPct}%`;

  const remaining = Math.round(targets.kcal - totals.kcal);
  calProgressText.textContent = `${fmt(Math.round(totals.kcal))} / ${fmt(Math.round(targets.kcal))} kcal • ${remaining >= 0 ? fmt(remaining) + " kcal remaining" : fmt(Math.abs(remaining)) + " kcal over"}`;
}

trackForm?.addEventListener("submit", (e) => {
  e.preventDefault();
  trackMsg.textContent = "";

  const dateStr = trackDate.value || isoToday();
  const key = foodSelect.value;
  const f = FOOD_DB[key];
  if (!f){
    trackMsg.textContent = "Select a food.";
    return;
  }

  let qty = Number(foodQty.value);
  if (!Number.isFinite(qty) || qty <= 0){
    trackMsg.textContent = "Enter a valid quantity.";
    return;
  }

  const items = loadLog(dateStr);

  if (f.custom){
    // Use custom fields, qty forced to 1
    const name = ($("#customName").value || "Custom item").trim();
    const kcal = Number($("#customKcal").value);
    const p = Number($("#customP").value || 0);
    const c = Number($("#customC").value || 0);
    const fat = Number($("#customF").value || 0);

    if (!Number.isFinite(kcal) || kcal <= 0){
      trackMsg.textContent = "For custom item, enter Custom calories (kcal).";
      return;
    }

    items.push({
      id: uid(),
      name,
      qtyLabel: "1 portion",
      kcal,
      p: Number.isFinite(p) ? p : 0,
      c: Number.isFinite(c) ? c : 0,
      f: Number.isFinite(fat) ? fat : 0,
    });
  } else if (f.unit === "egg"){
    qty = clamp(Math.round(qty), 1, 12);
    const m = calcFoodMacros(key, qty);
    items.push({
      id: uid(),
      name: f.name,
      qtyLabel: `${qty} eggs`,
      kcal: m.kcal,
      p: m.p, c: m.c, f: m.f
    });
  } else {
    qty = clamp(roundTo(qty, 5), 5, 2000);
    const m = calcFoodMacros(key, qty);
    items.push({
      id: uid(),
      name: f.name,
      qtyLabel: `${qty} g`,
      kcal: m.kcal,
      p: m.p, c: m.c, f: m.f
    });
  }

  saveLog(dateStr, items);
  trackMsg.textContent = "Added.";
  refreshTrackerTargets();
});

clearDayBtn?.addEventListener("click", () => {
  const dateStr = trackDate.value || isoToday();
  try { localStorage.removeItem(trackerKey(dateStr)); } catch(e){}
  refreshTrackerTargets();
});

trackDate?.addEventListener("change", () => refreshTrackerTargets());

// Init tracker
(function initTracker(){
  populateFoodSelect();
  trackDate.value = isoToday();
  refreshTrackerTargets();
})();
